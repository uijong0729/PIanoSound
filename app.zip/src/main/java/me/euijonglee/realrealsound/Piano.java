package me.euijonglee.realrealsound;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


import file.FileManager;
import service.RecordTimer;


public class Piano extends Activity {

    SoundPool soundPool;    //효과음 재생을 위한 soundpool
    Button bt;              //피아노 버튼
    int touchedSound[] = new int[18]; //soundpool을 담기위한 배열
    boolean isRecord = false; //(녹음중인가)
    boolean blackKey = false; //검은 건반이 on인지 체크
    Intent intent; //intent를 받아와 녹음+피아노 인지 피아노 연습인지 확인
    Intent intent_timer;

    //저장 할 때의 파일이름을 임시로 저장
    String temp = ".mp3";

    MediaRecorder recorder;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pianoui);
        intent = getIntent();

        int root = intent.getIntExtra("code", 0);
        if(root == MainActivity.PIANO_RECORD){
            isRecord = true;

            //타이머 가즈아
            intent_timer = new Intent(Piano.this, RecordTimer.class);
            startService(intent_timer);

            //초기 폴더 생성
            FileManager.fileInit(FileManager.FILE_PATH);

            String tempName = "/" + System.currentTimeMillis() + ".mp3";
            temp = tempName;

            if(recorder != null)
            {
                recorder.stop();
                recorder.release();
                recorder = null;
            }

            recorder = new MediaRecorder();
            recorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
            recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
            recorder.setOutputFile(FileManager.FILE_PATH + tempName);

            try{
                recorder.prepare();
                recorder.start();
            }
            catch (Exception e){
                e.printStackTrace();
            }


        }



        //안드로이드 버전이 롤리팝 이상인경우 builder를 통해 생성해야한다.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
            soundPool = (new SoundPool.Builder()).setMaxStreams(10).build();
        }else{
            soundPool = new SoundPool(10, AudioManager.STREAM_MUSIC, 0);
        }

        //도 레 미 파 솔 라 시 도
        touchedSound[0] = soundPool.load(this, R.raw.doo, 1);
        touchedSound[1] = soundPool.load(this, R.raw.re, 1);
        touchedSound[2] = soundPool.load(this, R.raw.mi, 1);
        touchedSound[3] = soundPool.load(this, R.raw.pa, 1);
        touchedSound[4] = soundPool.load(this, R.raw.sol, 1);
        touchedSound[5] = soundPool.load(this, R.raw.ra, 1);
        touchedSound[6] = soundPool.load(this, R.raw.si, 1);
        touchedSound[7] = soundPool.load(this, R.raw.hdo, 1);

        //도# 레# 파# 솔# 라# : x값이 ? 이상인 경우 검은건반으로 인식하여 해당 음계의 배열 +10 값을 # 음으로 한다.
        touchedSound[10] = soundPool.load(this, R.raw.doos, 1);
        touchedSound[11] = soundPool.load(this, R.raw.res, 1);
        touchedSound[13] = soundPool.load(this, R.raw.pas, 1);
        touchedSound[14] = soundPool.load(this, R.raw.sols, 1);
        touchedSound[15] = soundPool.load(this, R.raw.ras, 1);



        //버튼 터치
        bt = (Button) findViewById(R.id.pbt);

        TouchHandler th = new TouchHandler();
        bt.setOnTouchListener(th);

    }


    class TouchHandler implements View.OnTouchListener{
        float start = 0;
        float end = 0;

        @Override
        public boolean onTouch(View view, MotionEvent m) {

            int count = m.getPointerCount();
            if(count > 5) count = 5;
            final int action = m.getAction();
            final double PLUS = (9.0 + 0.25);
            double getKey = ((m.getY() / bt.getHeight()) * 10.0) * 0.8;


            //& 는 and연산을 비트연산으로 리턴합니다.
            switch (action & MotionEvent.ACTION_MASK)
            {

                case MotionEvent.ACTION_DOWN:
                    start = m.getY(); //나중에 피아노 건반 바꿀 때 화면 슬라이드 체크 시작지점

                        /*
                             전체를 8등분 했을때
                             도# = 0.75 ~ 1.25 = 10
                             레# = 1.75 ~ 2.25 = 11
                             파# = 3.75 ~ 4.25 = 13
                             솔# = 4.75 ~ 5.25 = 14
                             라# = 5.75 ~ 6.25 = 15

                         */
                        if(blackKey) //검정건반인 경우
                        {
                            if ((m.getX() > (bt.getWidth()) * 0.4d)) //검정건반 on이고  검정건반 영역을 눌렀을 경우
                            {
                                int getGunban = (int) (getKey + PLUS);
                                if(getGunban >= 10 && getGunban <= 15 && getGunban != 12)
                                {
                                    soundPool.play(touchedSound[getGunban], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                }
                                else
                                {
                                    soundPool.play(touchedSound[(int) getKey],  MainActivity.volume, MainActivity.volume, 0, 0,  MainActivity.accel);
                                }
                            }
                            else //검정건반 on 영역이 아닌 경우
                            {
                                soundPool.play(touchedSound[(int) getKey],  MainActivity.volume, MainActivity.volume, 0, 0,  MainActivity.accel);
                            }
                        }
                        else { //검정건반이 아닌 경우
                            soundPool.play(touchedSound[(int) getKey],  MainActivity.volume, MainActivity.volume, 0, 0,  MainActivity.accel);
                        }

                    break; //싱글터치 시작

                    case MotionEvent.ACTION_MOVE: //터치 움직임
                        end = m.getY(); // 나중에 피아노 건반 바꿀 때 end 지점 계산하기 위함
                        if(start - end < 100 && start - end > -100)
                        {
                            //무의미한 무빙은 무빙 인식에서 제외시킨다.
                            break;
                        }
                        else
                        {
                            if(blackKey)
                            {
                                if((m.getX() > (bt.getWidth()) * 0.4d))
                                {
                                    int getGunban = (int) (getKey + PLUS);
                                    if(getGunban >= 10 && getGunban <= 15 && getGunban != 12)
                                    {
                                        soundPool.play(touchedSound[getGunban], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                    }
                                    else
                                    {
                                        soundPool.play(touchedSound[(int) getKey], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                    }
                                }
                                else
                                {
                                    soundPool.play(touchedSound[(int) getKey], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                }
                            }
                            else
                            {
                                soundPool.play(touchedSound[(int) getKey], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                            }
                        }
                        break;  //무빙 종료

                    case MotionEvent.ACTION_UP: //터치에서 손 뗌
                        //재생종료
                        soundPool.autoPause();

                        //건반 바꾸기
                        if(start - end > 925)
                        {
                            bt.setBackgroundResource(R.drawable.table4);
                            blackKey = true;
                        }
                        else if(start - end < -925)
                        {
                            bt.setBackgroundResource(R.drawable.table);
                            blackKey = false;
                        }

                        break; //싱글터치 손 뗌

                    case MotionEvent.ACTION_POINTER_DOWN:   //멀티터치                          비트연산 우로 두칸 (0100 -> 0001)
                        //건반이 여러개인 경우
                        if(count > 1) {
                            if(blackKey)
                            {
                                if (m.getX() > (bt.getWidth()) * 0.4d) { //검정건반 영역

                                    for (int i = 0; i < count; i++) {
                                        int getGunban = (int) (((m.getY(i) / bt.getHeight()) * 10.0) * 0.8 + PLUS);

                                        if(getGunban >= 10 && getGunban <= 15 && getGunban != 12)
                                        {
                                            soundPool.play(touchedSound[getGunban], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                        }
                                        else
                                        {
                                            soundPool.play(touchedSound[(int) getKey], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                        }
                                    }
                                }
                                else //일반영역
                                {
                                    for (int i = 0; i < count; i++)
                                    {
                                        double index = ((m.getY(i) / bt.getHeight()) * 10.0) * 0.8;
                                        soundPool.play(touchedSound[(int) index], MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                    }

                                }
                            }
                            //검정검반 off인경우
                            else {
                                for (int i = 0; i < count; i++) {
                                    // 해당 버튼이 전체 길이의 몇 퍼센트를 차지하는지 구하고 80%를 곱해 8등분으로 바꾼 뒤 길이를 버튼으로 인식한다.
                                    soundPool.play(touchedSound[(int) (((m.getY(i) / bt.getHeight()) * 10.0) * 0.8)],
                                            MainActivity.volume, MainActivity.volume, 0, 0, MainActivity.accel);
                                }
                            }
                        }
                        break;

                    case MotionEvent.ACTION_POINTER_UP:
                        for(int i = 0 ; i < count ; i++)
                        {
                            soundPool.stop(touchedSound[(int)(((m.getY(i) / bt.getHeight()) * 10.0) * 0.8)]);
                        }
                        break;

                    default: break;


            }//switch

            return false;
        }
    }


    @Override
    public void onBackPressed() {

        if(soundPool != null) {
            soundPool.release();
            soundPool = null;
        }


        if(isRecord){
            if(recorder == null){
                finish();
            }
            stopService(intent_timer);
            recorder.stop();
            recorder.release();


            AlertDialog.Builder dial = new AlertDialog.Builder(Piano.this);
            dial.setTitle("녹음 파일 타이틀을 설정해 주세요");
            dial.setIcon(R.drawable.baseline_audiotrack_black_18dp);
            final EditText text = new EditText(Piano.this);
            dial.setView(text);


            dial.setPositiveButton("확인", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    ContentValues val = new ContentValues(10);
                    String title = "/" + text.getText().toString() + ".mp3";

                    val.put(MediaStore.MediaColumns.TITLE, text.getText().toString());
                    val.put(MediaStore.Audio.Media.ALBUM, "Audio Album");
                    val.put(MediaStore.Audio.Media.DISPLAY_NAME, "Recorded Audio");
                    val.put(MediaStore.Audio.Media.IS_RINGTONE, 1);
                    val.put(MediaStore.Audio.Media.IS_MUSIC, 1);
                    val.put(MediaStore.MediaColumns.DATE_ADDED, System.currentTimeMillis());
                    val.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp3");
                    val.put(MediaStore.Audio.Media.DATA, FileManager.FILE_PATH + title);

                    Uri audioUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, val);

                    Toast.makeText(Piano.this, "저장 되었습니다", Toast.LENGTH_SHORT).show();

                    if(audioUri == null)
                    {
                        Toast.makeText(Piano.this, "녹음 저장에 실패했습니다", Toast.LENGTH_SHORT).show();
                    }else {
                        Toast.makeText(Piano.this, "저장 되었습니다.", Toast.LENGTH_SHORT).show();
                    }

                    FileManager.rename(temp, title);

                    finish();
                }
            });
            dial.setNegativeButton("취소", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    Toast.makeText(Piano.this, "취소 되었습니다", Toast.LENGTH_SHORT).show();
                    finish();
                }
            });
            dial.show();

        }
        else {
            super.onBackPressed();
        }
    }
}



