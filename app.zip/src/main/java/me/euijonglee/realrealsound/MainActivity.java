package me.euijonglee.realrealsound;

import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.io.File;

import file.FileManager;
import settingUI.PianoSetting;
import settingUI.RecordSetting;

public class MainActivity extends AppCompatActivity {

    Button bringYourRecorder, bringYourPiano, bringBoth;
    public static final int PIANO_TEST = 0;
    public static final int PIANO_RECORD = 1;
    public static int currentVolume;
    public static float volume = 1.0f;
    public static float accel = 1.0f;

    //옥타브 수
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        File file  = new File(FileManager.directory + "/" + "config.txt");
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);

        currentVolume = am.getStreamVolume(AudioManager.STREAM_MUSIC);

        if(file.exists())
        {
            //설정파일에 있는 숫자를 볼륨 값으로 강제 조절한다.
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Integer.parseInt(FileManager.readTextFile(FileManager.directory, "config.txt")), 0);
        }


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        bringYourRecorder = (Button) findViewById(R.id.bringYourRecorder);
        bringYourPiano = (Button) findViewById(R.id.bringYourPiano);
        bringBoth = (Button) findViewById(R.id.bringBoth);


    }




    public void go(View view){
        Intent intent;
        switch (view.getId())
        {
            case R.id.bringBoth:
                Toast.makeText(this, "both", Toast.LENGTH_SHORT).show();
                intent = new Intent(this, Piano.class);
                intent.putExtra("code", PIANO_RECORD);
                startActivity(intent);

                break;
            case R.id.bringYourPiano:
                Toast.makeText(this, "piano", Toast.LENGTH_SHORT).show();
                intent = new Intent(this, Piano.class);
                intent.putExtra("code", PIANO_TEST);
                startActivity(intent);
                break;


            case R.id.bringYourRecorder:
                Toast.makeText(this, "recorder", Toast.LENGTH_SHORT).show();
                intent = new Intent(this, Recorder.class);
                startActivity(intent);

                break;
        }
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        Intent intent;
        switch (id)
        {
            case R.id.piano_settings:
                intent = new Intent(this, PianoSetting.class);
                startActivity(intent);
                break;
            case R.id.recorder_settings:
                intent = new Intent(this, RecordSetting.class);
                startActivity(intent);
                break;
            case R.id.exit_settings:
                finish();
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    //종료시 원래 설정을 복구 할 수 있도록
    @Override
    protected void onDestroy() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, 0);

        super.onDestroy();
    }



    @Override
    public void onBackPressed() {
        AudioManager am = (AudioManager) getSystemService(AUDIO_SERVICE);
        am.setStreamVolume(AudioManager.STREAM_MUSIC, currentVolume, 0);
        super.onBackPressed();
    }
}
