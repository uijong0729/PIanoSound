package me.euijonglee.realrealsound;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.ToggleButton;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

import file.FileManager;
import service.RecordTimer;


public class Recorder extends Activity {

    //녹음기
    MediaRecorder recorder;
    //재생기
    MediaPlayer player;

    //녹음시작과 녹음종료의 토글
    ToggleButton tb;

    //재생 뒤로 등 버튼
    Button readButton, goBack, editbt;

    //녹음 파일 리스트를 담기위한 배열
    String array[];

    //파일 이름을 지정할 때 입력받을 텍스트 폼
    EditText text;

    //타이머 호출을 위한 인텐트
    Intent intent_timer;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.recordui);

        //다른 레이아웃의 위젯을 제어하기 위해 timerViewer를 생성하는 것
        //timerViewer = getLayoutInflater().inflate(R.layout.timerlayout, null, false);


        //파일 초기화
        FileManager.fileInit(FileManager.FILE_PATH);


        tb = (ToggleButton) findViewById(R.id.rbt);
        toggleHandler toggle = new toggleHandler();
        tb.setOnClickListener(toggle);

        //녹음파일 재생 버튼
        readButton = (Button) findViewById(R.id.playbt);
        buttonHandler bth = new buttonHandler();
        readButton.setOnClickListener(bth);

        //뒤로가기 버튼
        goBack = (Button) findViewById(R.id.goback);
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(player != null) {
                    player.stop();
                    player.release();
                }
                if(intent_timer != null) {
                    stopService(intent_timer);

                }
                if(recorder != null){
                    recorder.stop();
                    recorder.release();
                }
                finish();
            }
        });

        //녹음파일 편집버튼 (삭제, 이름바꾸기)
        editbt = (Button) findViewById(R.id.editbt);
        editbt.setOnClickListener(new View.OnClickListener() {

            File file = new File(FileManager.FILE_PATH);
            String[] fileList = file.list();
            boolean[] checkedItems = new boolean[fileList.length];
            ArrayList<String> selected = new ArrayList<>();

            @Override
            public void onClick(View view) {

                //리스트 갱신
                fileList = file.list();
                checkedItems = new boolean[fileList.length];

                AlertDialog.Builder alert = new AlertDialog.Builder(Recorder.this);
                alert.setMultiChoiceItems(fileList, checkedItems , new DialogInterface.OnMultiChoiceClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i, boolean b) {
                        //체크 된다면
                        if(b)
                        {
                            selected.add(fileList[i]);
                        }
                        else{
                            selected.remove(fileList[i]);
                        }
                    }
                });

                //삭제 버튼
                alert.setPositiveButton("삭제", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                        //Log.i("selected", selected.toString());
                        for (int k = 0; k < selected.size(); k++)
                        {
                            File temp = new File(FileManager.FILE_PATH + "/" + selected.get(k));
                            if (temp.exists())
                            {
                                temp.delete();

                                //파일리스트 갱신
                                fileList = file.list();
                                Toast.makeText(Recorder.this, "삭제 되었습니다.", Toast.LENGTH_SHORT).show();
                            }
                            else {
                                Toast.makeText(Recorder.this, "파일 삭제에 실패한 건이 있습니다.", Toast.LENGTH_SHORT).show();
                            }
                        }

                        }
                });

                //취소버튼
                alert.setNegativeButton("취소", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        return;
                    }
                });


                alert.show();
            }
        });

    }

    public class buttonHandler implements View.OnClickListener{
        @Override
        public void onClick(View view) {
        File file = new File(FileManager.FILE_PATH);
         array = file.list();


        //배열로 만든 리스트 출력
        final AlertDialog.Builder dia = new AlertDialog.Builder(Recorder.this);
        dia.setTitle("다음 목록에서 선택하세요");

        dia.setItems(array, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String Audio = FileManager.FILE_PATH + "/" + array[i];



                if(player != null){
                    player.release();
                }

                try {
                    player = new MediaPlayer();
                    player.setDataSource(Audio);
                    player.prepare();
                    player.start();
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

            }
        });
         dia.setNegativeButton("취소", new DialogInterface.OnClickListener(){
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    return;
                }
         });

        dia.show();

        }
    }


     class toggleHandler implements View.OnClickListener{
        //현재시간 값이 파일명이므로 변수로 미리 잡아둔다
        String tempName = "/" + System.currentTimeMillis() + ".mp3";

        @Override
        public void onClick(View view) {
            if(!(tb.isChecked())) {
                //녹음 타이머 시작
                intent_timer = new Intent(Recorder.this, RecordTimer.class);
                startService(intent_timer);
                //레이아웃 인플레이터를 담은 timerviewr를 호출하여 다른 레이아웃의 위젯을 제어한다
               // ch = (Chronometer) timerViewer.findViewById(R.id.chronometer);
               // ch.start();

                if(recorder != null)
                {
                    recorder.stop();
                    recorder.release();
                    recorder = null;
                }
                recorder = new MediaRecorder();
                recorder.setAudioSource(MediaRecorder.AudioSource.DEFAULT);
                recorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AMR_NB);
                recorder.setOutputFile(FileManager.FILE_PATH + tempName);

                try{
                    recorder.prepare();
                    recorder.start();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
            }
            else{
                //녹음 타이머 종료
                if(intent_timer != null) {
                    stopService(intent_timer);
          //          ch.stop();
          //          ch.setBase(0);
                }

                if(recorder == null){
                    return;
                }

                recorder.stop();
                recorder.release();
                recorder = null;

                AlertDialog.Builder dial = new AlertDialog.Builder(Recorder.this);
                dial.setTitle("녹음 파일 이름을 설정해 주세요");
                dial.setMessage("파일 이름");
                dial.setIcon(R.drawable.baseline_audiotrack_black_18dp);
                text = new EditText(Recorder.this);
                dial.setView(text);
                //파일명에 쓸 텍스트


                dial.setPositiveButton("확인", new DialogInterface.OnClickListener() {


                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        String title = text.getText().toString() + ".mp3";
                        ContentValues val = new ContentValues(10);

                        val.put(MediaStore.MediaColumns.TITLE, "녹음파일");
                        val.put(MediaStore.Audio.Media.DISPLAY_NAME, "Recorded Audio");
                        val.put(MediaStore.Audio.Media.IS_RINGTONE, 1);
                        val.put(MediaStore.Audio.Media.IS_MUSIC, 1);
                        val.put(MediaStore.MediaColumns.DATE_ADDED, System.currentTimeMillis());
                        val.put(MediaStore.MediaColumns.MIME_TYPE, "audio/mp3");
                        val.put(MediaStore.Audio.Media.DATA, FileManager.FILE_PATH + title);

                        //Log.e("text", text.getText().toString());
                        //Log.e("title", title);
                        Uri audioUri = getContentResolver().insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, val);


                        if(audioUri == null)
                        {
                            Toast.makeText(Recorder.this, "저장에 실패했습니다", Toast.LENGTH_SHORT).show();
                        }
                        else
                        {
                            Toast.makeText(Recorder.this, "저장 되었습니다", Toast.LENGTH_SHORT).show();
                        }


                        FileManager.rename(tempName, title);

                        return;
                    }
                });
                dial.setNegativeButton("취소", new DialogInterface.OnClickListener(){
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Toast.makeText(Recorder.this, "취소 되었습니다", Toast.LENGTH_SHORT).show();

                        return;
                    }
                });

                dial.show();



            }
        }
    }

    @Override
    public void onBackPressed() {

        if(player != null) {
            player.stop();
            player.release();
        }
        if(intent_timer != null) {
            stopService(intent_timer);

        }
        if(recorder != null){
            recorder.stop();
            recorder.release();
        }

        super.onBackPressed();
    }
}

